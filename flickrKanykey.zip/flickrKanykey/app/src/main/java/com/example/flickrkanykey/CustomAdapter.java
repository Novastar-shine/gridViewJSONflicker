package com.example.flickrkanykey;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.flickrkanykey.models.Photo;

import java.util.List;

public class CustomAdapter extends BaseAdapter {
    private List<Photo> photos;
    private Context context;
    private LayoutInflater layoutInflater;

    public CustomAdapter(List<Photo> photos, Context context, LayoutInflater layoutInflater) {
        this.photos = photos;
        this.context = context;
        this.layoutInflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
    }

    @Override
    public int getCount() {
        return photos.size();
    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View view, ViewGroup parent) {
        if(view == null){
            view = layoutInflater.inflate(R.layout.row_grid_items, parent,false);
        }
        ImageView imageView = view.findViewById(R.id.imageView);
        GlideApp.with(context)
                .load(photos.get(position).getMedia().getM())
                .into(imageView);


        return view;
    }
}
