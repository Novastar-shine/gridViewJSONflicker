package com.example.flickrkanykey.models;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;
@Entity
public class MediaUrl {
    @SerializedName("m")
    @Expose
    @PrimaryKey
    private String m;

    public MediaUrl(String m) {
        this.m = m;
    }

    public String getM() {
        return m;
    }

    public void setM(String m) {
        this.m = m;
    }
}
