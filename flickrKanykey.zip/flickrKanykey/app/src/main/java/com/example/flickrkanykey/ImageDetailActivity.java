package com.example.flickrkanykey;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class ImageDetailActivity extends AppCompatActivity {
    TextView textView1, textView2, textView3, textView4, textView5, textView6;
    ImageView imageView2;
    String title, link, media, date_taken, description, published, author, tags;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_image_detail);
        initialize();
        getBundles();
        setFields();
    }

    private void getBundles() {
        Bundle extras = getIntent().getExtras();
        if(extras != null){
            title = extras.getString("title");
            link = extras.getString("link");
            media = extras.getString("media");
            date_taken = extras.getString("date_taken");
            description = extras.getString("description");
            published = extras.getString("published");
            author = extras.getString("author");
            tags = extras.getString("tags");
        }
    }

    private void setFields() {
        GlideApp.with(this).load(media).into(imageView2);
        textView1.setText(title);
        textView2.setText(date_taken);
        textView3.setText(published);
        textView4.setText(author);
        textView5.setText(tags);
        textView6.setText(description);
    }

    private void initialize() {
        imageView2=findViewById(R.id.imageView2);
        textView1=findViewById(R.id.textView);
        textView2=findViewById(R.id.textView2);
        textView3=findViewById(R.id.textView3);
        textView4=findViewById(R.id.textView4);
        textView5=findViewById(R.id.textView5);
        textView6=findViewById(R.id.textView6);
    }
}