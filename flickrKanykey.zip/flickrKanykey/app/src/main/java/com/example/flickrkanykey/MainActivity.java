package com.example.flickrkanykey;

import androidx.appcompat.app.AppCompatActivity;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.example.flickrkanykey.API.ApiClient;
import com.example.flickrkanykey.models.Photo;
import com.example.flickrkanykey.models.photoList;

import java.util.ArrayList;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {
GridView gridView;
    List<Photo> photos;
    SwipeRefreshLayout swipeRefreshLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initialize();
        checkInternetConnection();
        getAllImages();
        refreshLayout();

        gridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent intent = new Intent(getApplicationContext(),ImageDetailActivity.class);
                intent.putExtra("title",photos.get(position).getTitle());
                intent.putExtra("link",photos.get(position).getLink());
                intent.putExtra("media",photos.get(position).getMedia().getM());
                intent.putExtra("date_taken",photos.get(position).getDate_taken());
                intent.putExtra("description",photos.get(position).getDescription());
                intent.putExtra("published",photos.get(position).getPublished());
                intent.putExtra("author",photos.get(position).getAuthor());
                intent.putExtra("tags",photos.get(position).getTags());
                startActivity(intent);
            }
        });
    }

    private void checkInternetConnection() {
        if(isConnected()==true){
            Toast.makeText(this, "Internet Connected", Toast.LENGTH_SHORT).show();
        }else{
            Toast.makeText(this, "No Internet Connection", Toast.LENGTH_SHORT).show();
        }
    }

    boolean isConnected() {
        ConnectivityManager connectivityManager = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connectivityManager.getActiveNetworkInfo();
        if(networkInfo!=null){
            if(networkInfo.isAvailable()){
                return true;
            }else {
                return false;
            }
        }else{
            return false;
        }
    }


    private void refreshLayout() {
        swipeRefreshLayout.setOnRefreshListener(new SwipeRefreshLayout.OnRefreshListener() {
            @Override
            public void onRefresh() {
                checkInternetConnection();
                getAllImages();
            }
        });
    }

    private void initialize() {
        gridView = findViewById(R.id.gridView);
        photos = new ArrayList<>();
        swipeRefreshLayout=findViewById(R.id.refreshLayout);
    }
    public void getAllImages(){
        Call<com.example.flickrkanykey.models.photoList> imagesResponse = ApiClient.getInterface().getPhotoList();
        imagesResponse.enqueue(new Callback<photoList>() {
            @Override
            public void onResponse(Call<photoList> call, Response<photoList> response) {
                String message;
                if(response.isSuccessful()){
                    photos = response.body().getPhotos();
                    message = "Request Successful";
                    for(int i =0;i<photos.size();i++){
                        CustomAdapter customAdapter = new CustomAdapter(photos, MainActivity.this, getLayoutInflater());
                        gridView.setAdapter(customAdapter);
                        swipeRefreshLayout.setRefreshing(false);
                    }


                }else{
                    message = "An error occurred try again later";
                }
                System.out.println(message);
            }

            @Override
            public void onFailure(Call<photoList> call, Throwable t) {
                String message = t.getLocalizedMessage();
                Toast.makeText(MainActivity.this, "wrong"+message, Toast.LENGTH_SHORT).show();
                System.out.println(message);
            }
        });
    }

}